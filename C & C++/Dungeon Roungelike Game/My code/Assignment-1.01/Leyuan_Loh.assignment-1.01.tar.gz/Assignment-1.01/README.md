Blake Fisher: bdfisher <br />
Leyuan Loh:  leyuan <br />
Bo Sheng Lee: lee0717 <br /> 
  
### This is the requirements of the assignment 1.01
* Dimension of the dungeon must be (80 x 21)
* At least 6 rooms are created each time
* Each room fits minimum dimensions (4 x 3)
* 1 cell of non-room separates each rooms
* outermost cells are immutable
* dungeon is fully connected
* corridors do not extend into rooms
* at least one up and one down staircase.
* staircase should be placed on a floor
* room cells should be drawn with periods, corridor cells with hashes, rock with spaces, up staircases with less-than signs, and down staircases with greater-than signs.

<br />