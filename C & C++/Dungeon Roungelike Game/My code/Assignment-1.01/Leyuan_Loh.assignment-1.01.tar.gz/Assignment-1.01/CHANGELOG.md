<h3>2/6/21</h3>
* Initialized Repository and Created README
<h3>2/7/21</h3>
* Loh - Implemented initialization of the grid, output, generating rooms, and placing rooms.
<h3>2/8/21</h3>
* Lee - Modifying, refactoring and remove error of the code. Add new array to create corridor. <br />
* Blake - Created Makefile, Started figuring out how to connect the different rooms using corridors. <br />
* lee - Fix bugs and get the random room working correctly.
<h3>2/9/21</h3>
* Blake - worked more on creating corridors <br />
* Blake - finished createCorridors() <br />
<h3>2/9/21</h3>
* Loh - implemented placeStairs<br/>
<h3>2/11/21</h3>
* Finished assignment