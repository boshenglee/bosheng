### 2/16/21
* Started Assignment-1.02
* Blake - Started on load file
* Leyuan- Worked on getting path of file and command line arguments
### 2/17/21
* Leyuan - Completed load file functions. 
* Lee - Complete the save fiel functions.
### 2/18/21
* Leyuan - Dynamically initialize rooms arrays in dungeon_t
* Lee - Testing our program after changing the solution code.
* Finished Project