### 3/3/21
* Start seperating job for assignment 1.04
* Lee -  Start working on arguments, creating monster, placing monster and add them into heap
      - I added code in rlg327.c: `generate_monster_code(), generate_character(), init_monster(), main()`
* Blake - Started working on the "dumb" monster implementation
* Loh - Implemented the basic function for movement.   
### 3/4/21
* All - Worked multiple hours on trying to write working code. 
* Loh - Implemented the tunneling movement.
* Lee - Add smart and telepathic, erratic ability.