Blake Fisher: bdfisher <br />
Leyuan Loh:  leyuan <br />
Bo Sheng Lee: lee0717 <br /> <br />

So, for monster without intelligence ability, they will not know the shortest path to PC, so they will just randomly walk arounf the pc. For monster who dont have the ability of telepatic will also don know where is the pc location, so they will also walk around the map. Then, for monster without tunneling ability will not able to walk through the wall, they can only walk on corridor and room. There is a posibilities that the game go infinite loop cayse for monster without telepatic and not intelligens and not tunneling might stuck at a corner. 
