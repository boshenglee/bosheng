Steps to build:  (we have skipped tests)
mvn package

Steps to run it:
java -jar target/java-project-1.0-SNAPSHOT.jar

Steps to run the tests
mvn -DskipTests=false test
